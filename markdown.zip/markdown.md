---
title: Five minutes on Markdown for scientific publishing 
author: Martin Robinson
date: 11/05/2015
abstract: my descriptive abstract!
bibliography: "papers.bib"
---

Markdown is human-readable text
===============================

Features
--------

- Refer to Very Important Paper [@Robinson2015]
- Write your equations
$$ 
 E_{HGO}(\mathbf{u}_i, \mathbf{u}_j, \mathbf{r}) = 
 \begin{cases}
   \infty & r < \sigma(\mathbf{u}_i, \mathbf{u}_j, \hat{\mathbf{r}}), \\
   0 & \text{otherwise},
 \end{cases}
$$
- Include figures with captions and internal references

![Cholesteric liquid crystal pattern](images/cholesteric3.png)

